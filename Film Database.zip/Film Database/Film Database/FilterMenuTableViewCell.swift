//
//  FilterMenuTableViewCell.swift
//  Film Database
//
//  Created by Kendall Crouch on 11/18/18.
//  Copyright © 2018 Kendall Crouch. All rights reserved.
//

import UIKit

class FilterMenuTableViewCell: UITableViewCell {

    @IBOutlet weak var txtFilterTitle: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBAction func txtTitle_ACTION(_ sender: UITextField) {
        GlobalVariables.filterTitle = txtFilterTitle.text!
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
