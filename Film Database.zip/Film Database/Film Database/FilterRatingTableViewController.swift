//
//  FilterRatingTableViewController.swift
//  Film Database
//
//  Created by Kendall Crouch on 11/18/18.
//  Copyright © 2018 Kendall Crouch. All rights reserved.
//

import UIKit

class FilterRatingTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return GlobalVariables.ratings.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RatingCell", for: indexPath)
        cell.textLabel?.text = GlobalVariables.ratings[indexPath.row].rating
        if GlobalVariables.ratings[indexPath.row].selected {
            tableView.selectRow(at: indexPath, animated: false, scrollPosition: .none)
        }
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        GlobalVariables.ratings[indexPath.row].selected = true
    }
    
    override func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        GlobalVariables.ratings[indexPath.row].selected = false
    }
}
