//
//  MasterViewController.swift
//  Film Database
//
//  Created by Kendall Crouch on 11/17/18.
//  Copyright © 2018 Kendall Crouch. All rights reserved.
//

import UIKit

class MasterViewController: UITableViewController {

    var detailViewController: DetailViewController? = nil
    var filmList = [FilmDetail]()

    override func viewDidLoad() {
        super.viewDidLoad()

        GlobalVariables.categories.removeAll()
        GlobalVariables.ratings.removeAll()
        
        self.loadFilters(completion: { (jsonData) in
            if let json = jsonData {
                if let _ = json["ratings"] {
                    let jsonRatings = json["ratings"] as! NSArray;
                    if jsonRatings.count > 0 {
                        for item in jsonRatings {
                            let obj = item as! String
                            GlobalVariables.ratings.append(RatingDisplayItem(rating: obj, selected: false))
                        }
                    }
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                }
                if let _ = json["categories"] {
                    let jsonCategories = json["categories"] as! NSArray;
                    if jsonCategories.count > 0 {
                        for item in jsonCategories {
                            let obj = item as! NSDictionary
                            GlobalVariables.categories.append(CategoryDisplayItem(categoryID: (obj.value(forKey: "categoryID") as! Int16), category: (obj.value(forKey: "categoryName") as! String), selected: false))
                        }
                    }
                }
            }
        })
        
        let filterButton = UIBarButtonItem(title: "Filter", style: UIBarButtonItem.Style.plain, target: self, action: #selector(filterFilms(_:)))
        navigationItem.rightBarButtonItem = filterButton
        if let split = splitViewController {
            let controllers = split.viewControllers
            detailViewController = (controllers[controllers.count-1] as! UINavigationController).topViewController as? DetailViewController
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        filmList.removeAll()
        self.loadMovies(completion: { (jsonData) in
            if let json = jsonData {
                if let _ = json["movies"] {
                    let jsonMovies = json["movies"] as! NSArray;
                    if jsonMovies.count > 0 {
                        for item in jsonMovies {
                            let obj = item as! NSDictionary
                            let filmDetail = FilmDetail(filmID: obj.value(forKey: "filmID") as! Int16, title: obj.value(forKey: "title") as! String, releaseYear: obj.value(forKey: "releaseYear") as! Int16)
                            self.filmList.append(filmDetail)
                        }
                    }
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                }
            }
        })

    }

    override func viewWillAppear(_ animated: Bool) {
        clearsSelectionOnViewWillAppear = splitViewController!.isCollapsed
        super.viewWillAppear(animated)
    }

    @objc
    func filterFilms(_ sender: Any) {
        self.performSegue(withIdentifier: "showFilter", sender: self)
    }

    // MARK: - Segues

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            if let indexPath = tableView.indexPathForSelectedRow {
                let controller = (segue.destination as! UINavigationController).topViewController as! DetailViewController
                controller.detailItem = filmList[indexPath.row].filmID
                controller.navigationItem.leftBarButtonItem = splitViewController?.displayModeButtonItem
                controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }

    // MARK: - Table View

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filmList.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! FilmTableViewCell

        let film = filmList[indexPath.row]
        cell.lblTitle.text = film.title
        cell.lblReleaseDate.text = String(describing: film.releaseYear)
        return cell
    }

    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
//        if editingStyle == .delete {
//            objects.remove(at: indexPath.row)
//            tableView.deleteRows(at: [indexPath], with: .fade)
//        } else if editingStyle == .insert {
//            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
//        }
    }

    func loadMovies(completion: @escaping (_ jsonData: NSDictionary?)->Void) {
        
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: nil, delegateQueue: nil)
        
        guard let requestUrl = URL(string: "https://www.klccomputing.com/cbuilderc/getMovieList.php") else {return}
        var request = URLRequest(url: requestUrl as URL)
        request.httpMethod = "POST"
        
        request.addValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        var ratingFilters = [RatingItem]()
        for rating in GlobalVariables.ratings {
            if rating.selected {
                let ratingFilter = RatingItem(rating: rating.rating)
                ratingFilters.append(ratingFilter)
            }
        }
        var categoryFilters = [CategoryItem]()
        for category in GlobalVariables.categories {
            if category.selected {
                let categoryFilter = CategoryItem(category: String(describing: category.categoryID))
                categoryFilters.append(categoryFilter)
            }
        }
        let requestObject = RequestObject(ratings: ratingFilters, categories: categoryFilters, title: GlobalVariables.filterTitle)

        let jsonEncoder = JSONEncoder()
        do {
            let jsonData = try jsonEncoder.encode(requestObject)
            request.httpBody = jsonData
        }
        catch let _ as NSError {
            
        }
        
        let task = session.dataTask(with: request) { (data, response, error) in
            if (error == nil) {
                // Success
                let statusCode = (response as! HTTPURLResponse).statusCode
                print("URL Session Task Succeeded: HTTP \(statusCode)")
            }
            else {
                // Failure
                print("URL Session Task Failed: %@", error!.localizedDescription);
            }
            if let res = response as? HTTPURLResponse {
                if res.statusCode == 200 {
                    if let _ = data {
                        do {
                            let responseString = String(data: data!, encoding: .utf8)
                            print("responseString = \(String(describing: responseString))")
                            let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                            completion(_: json)
                        }
                        catch let _ as NSError {
                        }
                    }
                }
            }
        }
        task.resume()
        session.finishTasksAndInvalidate()
    }
    
    func loadFilters(completion: @escaping (_ jsonData: NSDictionary?)->Void) {
        
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: nil, delegateQueue: nil)
        
        guard let requestUrl = URL(string: "https://www.klccomputing.com/cbuilderc/getFilterList.php") else {return}
        var request = URLRequest(url: requestUrl as URL)
        request.httpMethod = "POST"
        
        request.addValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        let task = session.dataTask(with: request) { (data, response, error) in
            if (error == nil) {
                // Success
                let statusCode = (response as! HTTPURLResponse).statusCode
                print("URL Session Task Succeeded: HTTP \(statusCode)")
            }
            else {
                // Failure
                print("URL Session Task Failed: %@", error!.localizedDescription);
            }
            if let res = response as? HTTPURLResponse {
                if res.statusCode == 200 {
                    if let _ = data {
                        do {
                            let responseString = String(data: data!, encoding: .utf8)
                            print("responseString = \(String(describing: responseString))")
                            let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                            completion(_: json)
                        }
                        catch let _ as NSError {
                        }
                    }
                }
            }
        }
        task.resume()
        session.finishTasksAndInvalidate()
    }

    struct RequestObject: Codable {
        let ratings: [RatingItem]
        let categories: [CategoryItem]
        let title: String
    }
    
    struct RatingItem: Codable {
        let rating: String
    }
    
    struct CategoryItem: Codable {
        let category: String
    }
}
