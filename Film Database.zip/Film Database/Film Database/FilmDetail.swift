//
//  FilmDetail.swift
//  Film Database
//
//  Created by Kendall Crouch on 11/17/18.
//  Copyright © 2018 Kendall Crouch. All rights reserved.
//

import Foundation

class FilmDetail {
    var filmID : Int16 = -1
    var title : String = ""
    var releaseYear : Int16 = -1
    
    init(filmID: Int16, title: String, releaseYear: Int16) {
        self.filmID = filmID
        self.title = title
        self.releaseYear = releaseYear
    }
}
