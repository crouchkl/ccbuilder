//
//  DetailViewController.swift
//  Film Database
//
//  Created by Kendall Crouch on 11/17/18.
//  Copyright © 2018 Kendall Crouch. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblReleaseYear: UILabel!
    @IBOutlet weak var txtDescription: UITextView!
    @IBOutlet weak var lblRating: UILabel!
    @IBOutlet weak var lblCategory: UILabel!
    @IBOutlet weak var lblLength: UILabel!
    @IBOutlet weak var lblFeatures: UILabel!
    @IBOutlet weak var lblRentalRate: UILabel!
    @IBOutlet weak var lblRentalDuration: UILabel!
    @IBOutlet weak var lblReplacementCost: UILabel!
    @IBOutlet weak var txtActors: UITextView!
    

    func configureView() {
        // Update the user interface for the detail item.
        if let detail = detailItem {
            self.loadMovie(filmID: detail) { (jsonData) in
                if let json = jsonData {
                    if let _ = json["movie"] {
                        let jsonMovie = json["movie"] as! NSDictionary;
                        DispatchQueue.main.async {
                            self.lblTitle.text = "Title: " + (jsonMovie.value(forKey: "title") as! String)
                            self.lblReleaseYear.text = "Released: " + String(describing: (jsonMovie.value(forKey: "releaseYear") as! Int16))
                            self.txtDescription.text = "Description: " + (jsonMovie.value(forKey: "description") as! String)
                            self.lblRating.text = "Rating: " + (jsonMovie.value(forKey: "rating") as! String)
                            self.lblCategory.text = "Category: " + (jsonMovie.value(forKey: "category") as! String)
                            self.lblLength.text = "Length: " + String(describing: (jsonMovie.value(forKey: "length") as! Int16))
                            self.lblFeatures.text = "Features: " + (jsonMovie.value(forKey: "specialFeatures") as! String)
                            self.lblRentalRate.text = "Rental Rate: " + (jsonMovie.value(forKey: "rentalRate") as! String)
                            self.lblRentalDuration.text = "Rental Duration: " + String(describing: (jsonMovie.value(forKey: "rentalDuration") as! Int16))
                            self.lblReplacementCost.text = "Replacement Cost: " + (jsonMovie.value(forKey: "replacementCost") as! String)
                            if let _ = json["actors"] {
                                let actors = json["actors"] as! NSArray
                                var actorString = ""
                                for item in actors {
                                    let actor = item as! NSDictionary
                                    actorString.append(contentsOf: (actor.value(forKey: "actorName") as! String) + "\n")
                                }
                                self.txtActors.text = "Actors: \n" + actorString
                            }
                        }
                    }
                }
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        configureView()
    }

    var detailItem: Int16? {
        didSet {
            // Update the view.
            configureView()
        }
    }

    func loadMovie(filmID: Int16, completion: @escaping (_ jsonData: NSDictionary?)->Void) {
        
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: nil, delegateQueue: nil)
        
        guard let requestUrl = URL(string: "https://www.klccomputing.com/cbuilderc/getMovieDetails.php") else {return}
        var request = URLRequest(url: requestUrl as URL)
        request.httpMethod = "POST"
        
        request.addValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        let bodyObject = [
            "filmID": "\(filmID)"
            ] as [String : Any]
        
        request.httpBody = try! JSONSerialization.data(withJSONObject: bodyObject, options: [])
        
        let task = session.dataTask(with: request) { (data, response, error) in
            if (error == nil) {
                // Success
                let statusCode = (response as! HTTPURLResponse).statusCode
                print("URL Session Task Succeeded: HTTP \(statusCode)")
            }
            else {
                // Failure
                print("URL Session Task Failed: %@", error!.localizedDescription);
            }
            if let res = response as? HTTPURLResponse {
                if res.statusCode == 200 {
                    if let _ = data {
                        do {
                            let responseString = String(data: data!, encoding: .utf8)
                            print("responseString = \(String(describing: responseString))")
                            let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                            completion(_: json)
                        }
                        catch let _ as NSError {
                        }
                    }
                }
            }
        }
        task.resume()
        session.finishTasksAndInvalidate()
    }
}
