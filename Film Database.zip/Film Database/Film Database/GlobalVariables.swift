//
//  GlobalVariables.swift
//  Film Database
//
//  Created by Kendall Crouch on 11/18/18.
//  Copyright © 2018 Kendall Crouch. All rights reserved.
//

import Foundation

struct GlobalVariables {
    static var ratings = [RatingDisplayItem]()
    static var categories = [CategoryDisplayItem]()
    static var filterTitle = ""
}

struct RatingDisplayItem {
    var rating: String
    var selected: Bool
}

struct CategoryDisplayItem {
    var categoryID: Int16
    var category: String
    var selected: Bool
}
